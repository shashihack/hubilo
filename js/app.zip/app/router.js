define(function (require) {

    "use strict";

        var $    = require('jquery'),
        Backbone  = require('backbone'),
        ShellView  = require('app/views/Shell'),
        HomeView = require('app/views/Home'),
        HowitworksView  = require('app/views/Howitworks'),
        RequestdemoView  = require('app/views/Requestdemo'),

        $body = $('#body-root'),
        shellView = new ShellView({el: $body}).render(),
        $content = $("#content", shellView.el),
        homeView = new HomeView({el: $content}),
        howitworksView = new HowitworksView({el: $content}),
        requestdemoView = new RequestdemoView({el: $content});

    // Close the search dropdown on click anywhere in the UI
    $body.click(function () {
        $('.dropdown').removeClass("open");
    });

    $("body").on("click", "#showMeBtn", function (event) {
        event.preventDefault();
        shellView.search();
    });

    return Backbone.Router.extend({

        routes: {
            "": "home",
            "howitworks":"howitworks",
            "requestdemo":"requestdemo",
            "features/:id": "featureDetails"
        },

        home: function () {
            $body.find(".row-fluid").attr("id","home");
            window.scrollTo(0, 0);
            homeView.delegateEvents(); // delegate events when the view is recycled
            homeView.render();
        },

        howitworks: function () {
            $body.find(".row-fluid").attr("id","hiw");
            window.scrollTo(0, 0);
            howitworksView.delegateEvents(); // delegate events when the view is recycled
            howitworksView.render();
        },

        requestdemo: function () {
            $body.find(".row-fluid").attr("id","rad");
            window.scrollTo(0, 0);
            requestdemoView.delegateEvents(); // delegate events when the view is recycled
            requestdemoView.render();
        },

        featureDetails: function (id) {
            window.scrollTo(0, 0);
            require(["app/views/Feature", "app/models/feature"], function (FeatureView, models) {
                var feature = new models.Feature({id: id});
                feature.fetch({
                    success: function (data) {
                        // instead of creating new instances
                        $body.find(".row-fluid").attr("id","r_f_"+id);
                        var view = new FeatureView({model: data, el: $content});
                        view.render();
                    }
                });
            });
        }

    });

});
